import argparse, sys, copy, json, hashlib
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch
import torch

sys.path.insert(0, str(Path.cwd() / "scripts"))
from verify_audio_parity import audio_cases
from spleeterpt.checkpoint import load_model
from spleeterpt.audio import separate, read_audio


def sha(x):
    return hashlib.sha256(x.contiguous().numpy().tobytes()).hexdigest()


parser = argparse.ArgumentParser(
    description="Compare native and widened D6 execution to one archived process report. Run from the repository root."
)
parser.add_argument("--weights", type=Path, required=True)
parser.add_argument("--upstream-root", type=Path, required=True)
parser.add_argument("--report", type=Path, required=True)
args = parser.parse_args()
torch.set_num_threads(2)
model = load_model(args.weights / "5stems.pt").eval()
audio = read_audio(args.upstream_root / "audio_example.mp3", model.config.sample_rate)
cases = audio_cases(audio, model.config, True)
previous = json.loads(args.report.read_text())
results = {}
with torch.inference_mode():
    for arm in ("copy_native", "direct_wide"):
        with ExitStack() as stack:
            for net in model.unets.values():
                layer = net.decoder[5]
                if arm == "copy_native":
                    stack.callback(
                        layer.register_forward_hook(
                            lambda m, a, o: torch.empty_like(o).copy_(o)
                        ).remove
                    )
                else:
                    wide = copy.deepcopy(layer).double()
                    stack.enter_context(
                        patch.object(
                            layer,
                            "forward",
                            lambda x, wide=wide: wide(x.double()).to(torch.float32).contiguous(),
                        )
                    )
            rows = {}
            for name, wave in cases.items():
                outputs = separate(model, wave)
                hashes = {s: sha(v) for s, v in outputs.items()}
                ref = previous["cases"][name]["cells"][
                    "native" if arm == "copy_native" else "native_wide_conv6"
                ]
                rows[name] = {s: v == ref[s]["output_sha256"] for s, v in hashes.items()}
            results[arm] = rows
print(json.dumps(results))
